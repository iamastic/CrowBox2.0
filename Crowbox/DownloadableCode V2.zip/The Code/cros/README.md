## The Code for the CrOS is here!

### Watch the "Getting Started video on the Home page of the [website](). Download the code and edit it accordingly. 
